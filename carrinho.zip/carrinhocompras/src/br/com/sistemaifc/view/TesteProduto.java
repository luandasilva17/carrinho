package br.com.sistemaifc.view;

import br.com.sistemaifc.model.dao.ProdutoDAO;
import br.com.sistemaifc.model.vo.Produto;

public class TesteProduto {
    public static void main(String[] args) {
        ProdutoDAO pDAO = new ProdutoDAO();
        
        Produto produto = new Produto();
        produto.setIdProduto();
        
        
        System.out.println(pDAO.removerProduto(produto));
    }
}
